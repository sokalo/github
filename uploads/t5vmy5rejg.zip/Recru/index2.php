<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="en-US">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="en-US">
<![endif]-->
<!--[if !(IE 7) | !(IE 8) ]><!-->
<html class="js no-touch js_active  vc_desktop  vc_transform" lang="en-US"><!--<![endif]--><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<link rel="pingback" href="http://umgroups.com/cambodia/xmlrpc.php">
<title> Apply for Job Vacancy | UMG Cambodia</title>
<script type="text/javascript">var ajaxurl = 'http://umgroups.com/cambodia/wp-admin/admin-ajax.php';var themecolor='#eac404';</script>
<meta property="og:title" content="Business Development">
<meta property="og:type" content="article">
<meta property="og:locale" content="en_US">
<meta property="og:site_name" content="UMG Cambodia">
<meta property="og:url" content="http://umgroups.com/cambodia/?dtcareer=business-development">
<meta property="og:description" content="Completely synergize resource sucking relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas. Dynamically innovate resource-leveling customer service for state of the art customer service.">
<meta property="og:image" content="">
<meta property="fb:app_id" content="799143140148346">
<!--<link rel="alternate" type="application/rss+xml" title="UMG Cambodia » Feed" href="http://umgroups.com/cambodia/?feed=rss2">
<link rel="alternate" type="application/rss+xml" title="UMG Cambodia » Comments Feed" href="http://umgroups.com/cambodia/?feed=comments-rss2">-->
		<style type="text/css">
		input,select
		{
			height : 45px;
		}
		th,td
		{
			width: 200px;
		}
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>

<link href="jquery/jquery-ui.css" rel="stylesheet" type="text/css" />
 <style>
    .startdate{
     
    }
	.enddate{
		
	}
  </style>


<style type="text/javascript">
html {
    font-size:1rem
}
label {
    display:inline-block;
    margin:0 35px 25px 0;
    font-size:0;
}
label input {
    border-radius:4px;
    border:1px solid #000;
    width:100px;
    padding:3px 10px;
}
input:focus {
    border:1px solid red;
    box-shadow:0 0 5px rgba(0,0,0,0.3)
}
.label {
    display:inline-block;
    padding:0 10px;
}
fieldset {
    margin:0 0 20px;
    padding:20px 10px;
}
label * {
    font-size:16px;
    font-size:1rem;
    color: black;
}
.delete {
    display:none;
    color:red;
}
.data-added .delete{
    display:inline-block;       
}
</style>
   <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
<link rel="stylesheet" id="billio_report_post_icons-css" href="js/flaticon.css" type="text/css" media="all">
<link rel="stylesheet" id="contact-form-7-css" href="js/styles.css" type="text/css" media="all">
<link rel="stylesheet" id="essential-grid-plugin-settings-css" href="js/settings.css" type="text/css" media="all">
<link rel="stylesheet" id="tp-open-sans-css" href="js/css.css" type="text/css" media="all">
<link rel="stylesheet" id="tp-raleway-css" href="js/css_002.css" type="text/css" media="all">
<link rel="stylesheet" id="tp-droid-serif-css" href="js/css_004.css" type="text/css" media="all">
<link rel="stylesheet" id="tp-merriweather-css" href="js/css_003.css" type="text/css" media="all">
<link rel="stylesheet" id="tp-opensans-condensed-css" href="js/css_005.css" type="text/css" media="all">
<link rel="stylesheet" id="rs-plugin-settings-css" href="js/settings_002.css" type="text/css" media="all">
<style id="rs-plugin-settings-inline-css" type="text/css">
.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}
</style>
<link rel="stylesheet" id="woocommerce-layout-css" href="js/woocommerce-layout.css" type="text/css" media="all">
<link rel="stylesheet" id="woocommerce-smallscreen-css" href="js/woocommerce-smallscreen.css" type="text/css" media="only screen and (max-width: 768px)">
<link rel="stylesheet" id="woocommerce-general-css" href="js/woocommerce.css" type="text/css" media="all">
<link rel="stylesheet" id="billio_report_post_style-css" href="js/style.css" type="text/css" media="all">
<link rel="stylesheet" id="webfonts-font-css" href="js/webfonts.css" type="text/css" media="all">
<link rel="stylesheet" id="detheme-vc-css" href="js/plugin_style.css" type="text/css" media="all">
<link rel="stylesheet" id="wp-color-picker-css" href="js/color-picker.css" type="text/css" media="all">
<link rel="stylesheet" id="styleable-select-style-css" href="js/select-theme-default.css" type="text/css" media="all">
<!--[if IE 9]>
<link rel='stylesheet' id='billio-style-ie-css'  href='http://umgroups.com/cambodia/wp-content/themes/billio/css/ie9.css' type='text/css' media='all' />
<![endif]-->
<link rel="stylesheet" id="js_composer_front-css" href="js/js_composer.css" type="text/css" media="all">
<link rel="stylesheet" id="js_composer_custom_css-css" href="js/custom.css" type="text/css" media="screen">
<style type="text/css">
@import url(http://umgroups.com/cambodia/wp-content/themes/billio/style.css);
@import url(http://umgroups.com/cambodia/wp-content/themes/billio/css/bootstrap.css);
@import url(http://umgroups.com/cambodia/wp-content/themes/billio/css/flaticon.css);
@import url(http://umgroups.com/cambodia/wp-content/themes/billio/css/socialicons/flaticon.css);
@import url(//fonts.googleapis.com/css?family=Open+Sans:100,300,400,300italic,600,700&#038;subset=latin);
@import url(//fonts.googleapis.com/css?family=Open+Sans+Condensed:100,300,400,300italic,400italic,600,700,800);
@import url(//fonts.googleapis.com/css?family=Open+Sans+Condensed:700,700italic);
@import url(//fonts.googleapis.com/css?family=Merriweather:100,300,400,300italic,400italic,600,700);
@import url(http://umgroups.com/cambodia/wp-content/themes/billio/css/billio.css);
@import url(http://umgroups.com/cambodia/wp-content/themes/billio/css/mystyle.css);
@import url(http://umgroups.com/cambodia/wp-content/themes/billio/css/customstyle.css);
section#banner-section {background: url(js/career.png) no-repeat 50% 50%; max-height: 100%; background-size: 100% auto;
min-height:500px;
height:500px;}
div#head-page #dt-menu ul li.logo-desktop a {margin-top:19px;}
</style>
<link rel="shortcut icon" href="js/small-logo1.png">
<style type="text/css">
@import url(http://umgroups.com/cambodia/wp-content/themes/billio/iconfonts/social/flaticon.css);
@import url(http://umgroups.com/cambodia/wp-content/plugins/billio_icon_addon/iconfonts/industry/flaticon.css);
@import url(http://umgroups.com/cambodia/wp-content/plugins/billio_icon_addon/iconfonts/police/flaticon.css);
@import url(http://umgroups.com/cambodia/wp-content/plugins/billio_icon_addon/iconfonts/building-trade/flaticon.css);
@import url(http://umgroups.com/cambodia/wp-content/plugins/billio_icon_addon/iconfonts/industrial/flaticon.css);
@import url(http://umgroups.com/cambodia/wp-content/plugins/billio_icon_addon/iconfonts/ios7-set-filled-1/flaticon.css);
@import url(http://umgroups.com/cambodia/wp-content/plugins/billio_icon_addon/iconfonts/construction/flaticon.css);
@import url(http://umgroups.com/cambodia/wp-content/plugins/billio_icon_addon/iconfonts/logistics-delivery/flaticon.css);
@import url(http://umgroups.com/cambodia/wp-content/plugins/billio_icon_addon/iconfonts/miu-icons/flaticon.css);
@import url(http://umgroups.com/cambodia/wp-content/plugins/billio_icon_addon/iconfonts/stationery/flaticon.css);
</style>
<script type="text/javascript" src="js/jquery_005.js"></script>
<script type="text/javascript" src="js/jquery-migrate.js"></script>
<script type="text/javascript" src="js/report.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/lightbox.js"></script>
<script type="text/javascript" src="js/jquery_004.js"></script>
<script type="text/javascript" src="js/jquery_009.js"></script>
<script type="text/javascript" src="js/jquery_008.js"></script>
<script type="text/javascript" src="js/jquery_008.js"></script>
<script type="text/javascript" src="jquery/jquery.min.js"></script>
<script type="text/javascript" src="jquery/jquery-ui.min.js"></script>
<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress.">
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="http://umgroups.com/cambodia/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.css" media="screen"><![endif]--><!--[if IE  8]><link rel="stylesheet" type="text/css" href="http://umgroups.com/cambodia/wp-content/plugins/js_composer/assets/css/vc-ie8.css" media="screen"><![endif]--><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">.esgbox-margin{margin-right:0px;}</style>
<script type="text/javascript">
    var datefield=document.createElement("input")
    datefield.setAttribute("type", "date")
    if (datefield.type!="date"){ //if browser doesn't support input type="date", load files for jQuery UI Date Picker
        document.write('<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css" />\n')
        document.write('<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"><\/script>\n')
        document.write('<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"><\/script>\n') 
    }
</script>
 <!--
<script>


$( "<input>" ).is( ":text" );
if (datefield.type!="date"){ //if browser doesn't support input type="date", initialize date picker widget:
    jQuery(function($){ //on document.ready
        $('.startdate').datepicker();
		$('.enddate').datepicker();
		
	})
}
</script>-->


<!--- java script for date function---->
<script type="text/javascript">
        // this one uses classes
$(function() {
    $('body').on('focus', ".from, .to", function() {
        $('.from,.to').datepicker({
            defaultDate: "+1w",
            changeMonth: true,
            dateFormat: 'dd-mm-yy',
            numberOfMonths: 1,
            onClose: function(selectedDate) {
                if ($(this).hasClass('from')){
                                 var theOtherDate = $(this).closest('label').next('label').find('.to');
                                 $(theOtherDate).datepicker("option", "minDate", selectedDate);
                                } else {
                       //          var theOtherDate = $(this).closest('label').prev('label').find('.from');
                //$(theOtherDate).datepicker("option", "maxDate", selectedDate);  
                                }
                //$(this).valid();// for validate plugin
            }
        });
     })
});


//this is the baic version with ids
$(function() {
    $("#from").datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        dateFormat: 'dd-mm-yy',
        numberOfMonths: 1,
        onClose: function(selectedDate) {
            $("#to").datepicker("option", "minDate", selectedDate);
           
        }
    });
    $("#to").datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        dateFormat: 'dd-mm-yy',
        numberOfMonths: 1,
        onClose: function(selectedDate) {
            $("#from").datepicker("option", "maxDate", selectedDate);
            
        }
    });
});
// add for educational background
$(function() {
  var formNameIncrement = 0;
  var formNameValue = 0;
    $("body").on("click", ".add", function(e) {
        var mytarget = $(this).closest('.clonable').find('.clone:last');
        var myparent = $(this).closest('.clonable');
        var theCloneHtml = '<div class="clone" id="cloneID' + formNameIncrement + '">';
        var theCloneId = 'cloneID' + formNameIncrement;
        myparent.addClass('data-added');
        mytarget.after($(theCloneHtml).append('<div class="input-row"> <table>' +
                                   '<tr>' +
                                   '<td>' +
                                   '<label style="width:150px;">School Name</label><span><input  type="text" name="education[]"></span>' +
                                   '</td>' +
                                    '<td>' +
                                    '<label>Start Date</label><br><span><input class="to inp" type="text" name="education[]"></span>' +
                                    '</td>' +
                                    '<td>' +
                                    '<label>End Date<span><br><input class="from inp" type="text" name="education[]"></span>' +
                                    '</td>' +
                                    '<td>' +
                                    '<label style="width:150px;">Place of school</label><span ><input  type="text" name="education[]" ></span>' +
                                    '</td>' +
                                '</tr>' +
                            '</table></div>'));
        $(theCloneId).hide().fadeIn('slow');
        formNameIncrement++;
                e.preventDefault();
    });

 // when delete  is clicked
    $("body").on("click", ".delete", function(e) {
        var mynum = $(this).closest('.clonable').find('.clone').length;
        var mytarget = $(this).closest('.clonable').find('.clone:last');
        var myparent = $(this).closest('.clonable');
        if (mynum === 1) {
            myparent.removeClass('data-added')
        }
        mytarget.fadeOut();
        mytarget.remove();
                e.preventDefault();
 
    });
});
// add for foreign lanaguage
$(function()
{
    var formNameIncrementf = 0;
    var formNameValuef = 0;
    $("body").on("click", "")
}
// add for workimg experiences



</script>
<!--date function for java script-->
<script type="text/javascript">
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/cambodia\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/cambodia\/?dtcareer=business-development&wc-ajax=%%endpoint%%","i18n_view_cart":"View Cart","cart_url":"","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type="text/javascript" src="js/add-to-cart.js"></script>
<script type="text/javascript" src="js/woocommerce-add-to-cart.js"></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://umgroups.com/cambodia/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://umgroups.com/cambodia/wp-includes/wlwmanifest.xml"> 
<link rel="prev" title="Marketing" href="http://umgroups.com/cambodia/?dtcareer=marketing">
<meta name="generator" content="WordPress 4.3.1">
<meta name="generator" content="WooCommerce 2.4.10">
<link rel="canonical" href="http://umgroups.com/cambodia/?dtcareer=business-development">
<link rel="shortlink" href="http://umgroups.com/cambodia/?p=12444">
	



</head>
<body class="single single-dtcareer postid-12444 dt_custom_body wpb-js-composer js-comp-ver-4.7.4 vc_responsive">

	
<input name="nav" id="main-nav-check" type="checkbox">


<div class="top-head topbar-here is-sticky-menu sticky">


<div id="head-page" class="head-page adminbar-not-here reveal hastopbar solid stickysolid menu_background_color">
	<div class="container">
		<div style="height: auto;" id="dt-menu" class="dt-menu-pagebar"><label for="main-nav-check" class="toggle" onclick="" title="Close"><i class="icon-cancel-1"></i></label><ul id="menu-main-menu" class=""><li class="logo-desktop" style="width:150px;"><a href="http://www.umgmyanmar.com" style=" width:150px;"><img id="logomenu" src="" alt="" class="img-responsive halfsize" width="150"><img id="logomenureveal" src="js/small-logo2.png" alt="" class="img-responsive halfsize" width="150" height="50px"></a></li><li id="menu-item-12903" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-12903"><a href="#"><span style="color:white;">Secret</span></a><label for="fof12903" class="toggle-sub" onclick="">›</label>
        <input id="fof12903" class="sub-nav-check" type="checkbox">
       
</li>

</ul><label class="toggle close-all" onclick="uncheckboxes('nav')"><i class="icon-cancel-1"></i></label></div>	</div>

	<div class="container">
		<div class="row">
			<div>
                <div id="mobile-header" class="hidden-sm-max col-sm-12">
                    <label for="main-nav-check" class="toggle" onclick="" title="Menu"><i class="icon-menu"></i></label>
                    <a href="http://umgroups.com/cambodia" style=""><img id="logomenumobile" src="js/small-logo1.png" rel="http://umgroups.com/cambodia/wp-content/uploads/2015/11/small-logo1.png" alt="" class="img-responsive halfsize" width="150"><img id="logomenurevealmobile" src="js/small-logo2.png" alt="" class="img-responsive halfsize" width="150"></a>				</div><!-- closing "#header" -->
			</div>
		</div>
	</div>
</div>
</div>

<section style="margin-top: -42px;" id="banner-section" class="">
<div class="container no_subtitle">
	<div class="row">
		<div class="col-xs-12">		
			</br>
			</br>
			</br>
			</br>
			</br>
			</br>
			

			<div class="banner-title">  <h1 class="page-title">Job Application</h1></div>
			<div class="breadcrumbs"><span><a href="#" title="Home">Home</a></span>&nbsp;/&nbsp;
			<span><a href="#" title="Career">Career</a></span>&nbsp;/&nbsp;
			<span class="current">Job Application</span></div>			</div>
		</div>
</div>
</section>



<div class="blog single-post content nosidebar post-12444 dtcareer type-dtcareer status-publish hentry dtcareer_cat-all-opening dtcareer_cat-development dtcareer_cat-marketing">
<div class="container">
		<div class="row">
				<div class="col-xs-12">
<div style="display: none;" id="career_apply_12444" class="career-form modal fade" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
	    <div class="modal-content">
	    	<div class="md-description">
	    		<div class="heading-career-form">Please complete the form below to send an application for the selected job Business Development.</div>
	    		<h2 class="title-career-form">Apply Now</h2>
	    		<form id="career-form" method="post" action="" enctype="multipart/form-data">
				  <div class="form-group">
				    <label for="fullname">Full Name:</label>
				    <input name="fullname" class="form-control" id="fullname" placeholder="e.g. John Smith" required="" type="text">
				  </div>
				  <div class="form-group">
				    <label for="email_address">Email:</label>
				    <input name="email_address" class="form-control" id="email_address" placeholder="e.g. john.smith@hotmail.com" required="" type="email">
				  </div>
				  <div class="form-group">
				    <label for="note">Covering Note:</label>
				    <textarea class="form-control" name="note" rows="5" required=""></textarea>
				  </div>
				  <div class="form-group">
				    <label for="file_cv">Upload CV:</label>
				    <input name="file_cv" id="file_cv" required="" type="file">
				    <p class="help-block">Maximum file size 1.00Mb</p>
				  </div>
				  <button type="submit" class="btn btn-color-secondary">Apply Now</button>
				  <input name="career_id" id="career_id" value="12444" type="hidden">
				</form>
	    	</div>
		    <button class="button right btn-cross md-close" data-dismiss="modal"><i class="icon-cancel"></i></button>
	     </div>
 	</div>
</div>
<div id="career_send_12444" class="career-form modal fade" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
	    <div class="modal-content">
	    	<div class="md-description">
	    		<div class="heading-career-form">Please complete the form below to tell a friend about job Business Development.</div>
	    		<h2 class="title-career-form">Email To a Friend</h2>
	    		<form id="career-send-form" method="post" action="">
				  <div class="form-group">
				    <label for="fullname">Full Name:</label>
				    <input name="fullname" class="form-control" id="fullname" placeholder="e.g. John Smith" required="" type="text">
				  </div>
				  <div class="form-group">
				    <label for="email_address">Email:</label>
				    <input name="email_address" class="form-control" id="email_address" placeholder="e.g. john.smith@hotmail.com" required="" type="email">
				  </div>
				  <div class="form-group">
				    <label for="friend_email_address">Friend Email:</label>
				    <input name="friend_email_address" class="form-control" id="friend_email_address" placeholder="e.g. alice@hotmail.com" required="" type="email">
				  </div>
				  <div class="form-group">
				    <label for="note">Quick Note:</label>
				    <textarea class="form-control" name="note" rows="5"></textarea>
				    <p class="help-block">Type a quick message directed to your 
friend. Please avoid content that could be considered as spam as this 
could result in a ban from the site.</p>
				  </div>
				  <button type="submit" class="btn btn-color-secondary">Send Message</button>
				  <input name="career_id" id="career_id" value="12444" type="hidden">
				</form>
	    	</div>
		    <button class="button md-close right btn-cross" data-dismiss="modal"><i class="icon-cancel"></i></button>
	     </div>
	  </div>
</div>
<div class="career-detail">
	<h1>Application Form</h1>
	<div class="row">
		<div class="col-sm-8">
			<div class="row">
				<div class="col-xs-12">
					
				<!--	<table width="20%" align="center">-->
		<form class="commentForm" action="application_action.php" method="post" enctype="multipart/form-data">
			<!--<th colspan="2" align="left"><h2>APPLICATION FORM</h3></th>-->
		<ul class="career-detail-list">
		<li class="career-field">
		<label for="job-position">Job Position:</label><span class="career-value"><select name="jobposition"><option>Any Position</option><option>Other Position</option></select></span></li>
		<li class="career-field"><label for="job-position">Name:</label><span class="career-value"><input type="text" name="txtname" required/></span></li>
		<li class="career-field"><label for="job-position">Address:</label><span class="career-value"><input type="text" name="txtaddress" width="50" required/></span></li>
		<li class="career-field"><label for="job-position">Place Birth:</label><span class="career-value"><input type="text" name="txtplaceofbirth"  required/></span></li>
		<li class="career-field"><label for="job-position">Date of Birth:</label><span class="career-value"><input type="text" name="txtdob"  required/></span></li>
		<li class="career-field"><label for="job-position">NRC/Passport Number:</label><span class="career-value"><input type="text" name="txtnrc" required/></span></li>
		<li class="career-field"><label for="job-position">Phone No:</label><span class="career-value"><input type="text" name="txtphoneno" required/></span></li>
		<li class="career-field"><label for="job-position">Email Address:</label><span class="career-value"><input type="email" name="txtemail" required/></span></li>
		<li class="career-field"><label for="job-position">Gender:</label><span class="career-value"><select name="gender"><option>Male</option><option>Female</option></select></span></li>
		<li class="career-field"><label for="job-position">Marrital Status:</label><span class="career-value"><select name="marritalstatus"><option>Married</option><option>Not Married</option></select></span></li>
		<li class="career-field"><label for="job-position">Education Background:</label><br/></li>
		
		<li class="career-field">
		<!--<div>-->
		 <fieldset class="clonable">
                <legend>Add The High School Information Here</legend>
                <div class="clone">
                        <div class="input-row">
                            <table>
                                <tr>
                                   <td>
                                     <label style="width:150px;">School Name</label><span><input  type="text" name="education[]"></span>
                                    </td>
                                    <td>
                                    <label>Start Date</label><br><span><input class="to inp" type="text" name="education[]"></span>
                                    </td>
                                    <td>
                                    <label>End Date<span><br><input class="from inp" type="text" name="education[]"></span>
                                    </td>
                                 
                                    <td>
                                        <label style="width:150px;">Place of school</label><span ><input  type="text" name="education[]" ></span>
                                    </td>
                                </tr>
                            </table>
                             
                        </div>
                </div>
                <div>
                        <button class="delete">Delete last row</button>
                        <button class="add">Add another row</button>
                </div>
        </fieldset>
		<!--	</div>-->
			</li>
		     <li class="career-field">
			 <fieldset class="clonable">
                <legend>Add The University Information Here</legend>
                <div class="clone">
                        <div class="input-row">
                            <table>
                                <tr>
                                   <td>
                                     <label style="width:150px;">School Name</label><span><input  type="text" name="education[]"></span>
                                    </td>
                                    <td>
                                    <label>Start Date</label><br><span><input class="to inp" type="text" name="education[]"></span>
                                    </td>
                                    <td>
                                    <label>End Date<span><br><input class="from inp" type="text" name="education[]"></span>
                                    </td>
                                 
                                    <td>
                                        <label style="width:150px;">Place of school</label><span ><input  type="text" name="education[]" ></span>
                                    </td>
                                </tr>
                            </table>
                             
                        </div>
                </div>
                <div>
                        <button class="delete">Delete last row</button>
                        <button class="add">Add another row</button>
                </div>
             </fieldset>
			</li>
			
			<li class="career-field">
			 <fieldset class="clonable">
                <legend>Add The Other Qualification Information Here</legend>
                <div class="clone">
                        <div class="input-row">
                            <table>
                                <tr>
                                   <td>
                                     <label style="width:150px;">School Name</label><span><input  type="text" name="education[]"></span>
                                    </td>
                                    <td>
                                    <label>Start Date</label><br><span><input class="to inp" type="text" name="education[]"></span>
                                    </td>
                                    <td>
                                    <label>End Date<span><br><input class="from inp" type="text" name="education[]"></span>
                                    </td>
                                 
                                    <td>
                                        <label style="width:150px;">Place of school</label><span ><input  type="text" name="education[]" ></span>
                                    </td>
                                </tr>
                            </table>
                             
                        </div>
                </div>
                <div>
                        <button class="delete">Delete last row</button>
                        <button class="add">Add another row</button>
                </div>
        </fieldset>
			</li>
			<li class="career-field"><label for="job-position">Foreign Language:</label></li>
			<li class="career-field">
			<div>
				
				<table>
					<tr>
						<th>Languages</th>
						<th>Speaking</th>
						<th>Reading</th>
						<th>Writing</th>
						
					</tr>
					<tr>
						<td colspan="4">

								<table id="myTable3">
								  <tr>
									<td><input type="text" name="foreignlanguage[0]">&nbsp;</td>
									<td style=":10px;">
										</br>
										<select name="foreignlanguage[1]">
											<option >Beginner</option>
											<option>Conversational</option>
											<option>Business</option>
											<option>Fluent</option> 
										</select>
										&nbsp;</td>
									<td>
										</br>
										<select name="foreignlanguage[2]">
												<option >Beginner</option>
												<option>Conversational</option>
												<option>Business</option>
												<option>Fluent</option> 
										</select>&nbsp;
									</td>
									<td>
										</br>
									    <select name="foreignlanguage[3]">
											<option >Beginner</option>
											<option>Conversational</option>
											<option>Business</option>
											<option>Fluent</option> 
										</select>&nbsp;
									</td>
									<td>
									<input type="button" value="+" onclick="myFunction3()">
									</td>
									<td>
									<input type="button" value="-" onclick="myDeleteFunction3()">
									</td>
								  </tr>
								</table>

						</td>
					
					</tr>
				</table>
			</div>
			</li>
			<li class="career-field"><label for="job-position">Working Experiences:</label></li>
			<li class="career-field">
			<div>
				<table>
					<tr>
						<th><b/>Company Name</th>
						<th><b/>Latest Position</th>
						<th><b/>Period</th>&nbsp;
						<th align="right"><b/>&nbsp;Latest Salary</th>
						<th  align="center"><b/>&nbsp;&nbsp;&nbsp;Reason For Leaving</th>
						<th><input type="button" value="+" onclick="myFunction4()"></th>
						<th><input type="button" value="-" onclick="myDeleteFunction4()"></th>
					</tr>
					<tr>
						<td colspan="5">

								<table id="myTable4" align="left">
								  <tr>
										<td><input type="text" name="workexperience[0]">&nbsp;</td>
										<td><input type="text" name="workexperience[1]">&nbsp;</td>
										<td><input type="text" name="workexperience[2]">&nbsp;</td>
										<td><input type="text" name="workexperience[3]">&nbsp;</td>
										<td><input type="text" name="workexperience[4]">&nbsp;</td>
									
								  </tr>
								</table>

						</td>
					
					</tr>
				</table>
			</div>
			</li>
			<li class="career-field"><label for="job-position">References:</label></li>
			<li class="career-field">
			<div>
				<table>
					<tr>
						<th><b/>Name</th>
						<th><b/>Relationship</th>
						<th><b/>Phone/Address</th>&nbsp;
						<th align="right"><b/>&nbsp;Company</th>
						<th  align="center"><b/>&nbsp;&nbsp;&nbsp;Email</th>
						<th><input type="button" value="+" onclick="myFunction5()"></th>
						<th><input type="button" value="-" onclick="myDeleteFunction5()"></th>
					</tr>
					<tr>
						<td colspan="5">

								<table id="myTable5" align="left">
								  <tr>
										<td><input type="text" name="reference[0]">&nbsp;</td>
										<td><input type="text" name="reference[1]">&nbsp;</td>
										<td><input type="text" name="reference[2]">&nbsp;</td>
										<td><input type="text" name="reference[3]">&nbsp;</td>
										<td><input type="text" name="reference[4]">&nbsp;</td>
									
								  </tr>
								</table>

						</td>
					
					</tr>
				</table>
			</div>
			</li>
			
			<li class="career-field"><label for="job-position">Reason To Join UMG:</label><span class="career-value"><input type="text" name="txtjoinumg" width="50px"/></span></li>
			<li class="career-field"><label for="job-position">Expected Salary:</label><span class="career-value"><input type="text" name="txtexpectedsalary" width="50px"/></span></li>
			<li class="career-field"><label for="job-position">Strong Point:</label><span class="career-value"><textarea name="strongpoint" col="150" rows="5"></textarea></span></li>
			<li class="career-field"><label for="job-position">Weak Point:</label><span class="career-value"><textarea name="weakpoint" col="150" rows="5"></textarea></span></li>
			<li class="career-field"><label for="job-position">Attachment:</label><span class="career-value">  <input type="file" name="file" id="certificatecopy" onchange="checkFile()"></span></li>
		<!--<tr>
			<td><input type="submit" name="btnapply" value="Apply Now"></td>
			
		</tr>-->
		<div class="row">
			<div class="col-xs-12 col-sm-8 career-action-button"><input type="submit" name="btnapply" id="btnapply" value="Apply Now" class="btn btn-color-secondary">
			</div>
		</div>
		</ul>
	</form>

			</div>
		
			</div>
		
		</div>
		<div class="col-sm-4"><h3>Read me</h3>
					<p>Welcome to UMG recruitment program. Please ensure that everything you write in this form is as accurate as possible and backed by proper document.</p>
			<p>For the attachment, <u> please put your latest education certificate, Copy of your NRC/Passport, and other supporthing document</u> and <b>attached as single ZIP file.</b></p>
			<p>We will review all the incoming application and inform you by email if you are selected to the next recruitment process. Please ensure you input the right email address.</p>
		</div>
	</div>
</div>



</div><!-- content area col-9 -->

	

		</div><!-- .row -->

	</div><!-- .container -->

</div>
<div class="box-container vc_row wpb_row vc_row-fluid vc_row-fluid  footer-on-dark-bg vc_custom_1429091507102"><div class="container dt-container"><div class="row">
	<div class="vc_col-sm-5 wpb_column column_container vc_custom_1429092087166">
		<div class="wpb_wrapper">
			
	<div class="wpb_text_column wpb_content_element  text-centered-under-sm">
		<div class="wpb_wrapper">
			<p>© 2015&nbsp;United Mercury Group, LTD</p>

		</div> 
	</div> 
		</div> 
	</div> 

	<div class="vc_col-sm-7 wpb_column column_container">
		<div class="wpb_wrapper">
			<div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1429147194406"><div class="wpb_column vc_column_container vc_col-sm-3 vc_custom_1429150477804"><div class="wpb_wrapper">
    <div class="wpb_single_image wpb_content_element vc_align_center">
        <div class="wpb_wrapper">
            
            <div class="vc_single_image-wrapper   vc_box_border_grey"></div>
        </div>
    </div>
</div></div><div class="wpb_column vc_column_container vc_col-sm-3 vc_custom_1429150489762"><div class="wpb_wrapper">
    <div class="wpb_single_image wpb_content_element vc_align_center">
        <div class="wpb_wrapper">
            
            <div class="vc_single_image-wrapper   vc_box_border_grey"></div>
        </div>
    </div>
</div></div><div class="wpb_column vc_column_container vc_col-sm-3 vc_custom_1429147168340"><div class="wpb_wrapper">
    <div class="wpb_single_image wpb_content_element vc_align_center">
        <div class="wpb_wrapper">
            
            <div class="vc_single_image-wrapper   vc_box_border_grey"></div>
        </div>
    </div>
</div></div><div class="wpb_column vc_column_container vc_col-sm-3 vc_custom_1429147180175"><div class="wpb_wrapper">
    <div class="wpb_single_image wpb_content_element vc_align_center">
        <div class="wpb_wrapper">
            
            <div class="vc_single_image-wrapper   vc_box_border_grey"></div>
        </div>
    </div>
</div></div></div>
		</div> 
	</div> 
</div></div></div>

<link rel="stylesheet" id="flexslider-css" href="js/flexslider.css" type="text/css" media="screen">
<script type="text/javascript" src="js/jquery_010.js"></script>
<script type="text/javascript">
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/umgroups.com\/cambodia\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"Sending ..."};
/* ]]> */
</script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/cambodia\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/cambodia\/?dtcareer=business-development&wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type="text/javascript" src="js/woocommerce.js"></script>
<script type="text/javascript" src="js/jquery_007.js"></script>
<script type="text/javascript">
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/cambodia\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/cambodia\/?dtcareer=business-development&wc-ajax=%%endpoint%%","fragment_name":"wc_fragments"};
/* ]]> */
</script>
<script type="text/javascript" src="js/cart-fragments.js"></script>
<script type="text/javascript" src="js/modernizr.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/myscript.js"></script>
<script type="text/javascript" src="js/select_002.js"></script>
<script type="text/javascript" src="js/select.js"></script>
<script type="text/javascript" src="js/jquery_003.js"></script>
<script type="text/javascript" src="js/jquery_002.js"></script>
<script type="text/javascript" src="js/career.js"></script>
<script type="text/javascript" src="js/js_composer_front.js"></script>
<script type="text/javascript" src="js/jquery_006.js"></script>
<script type="text/javascript">                jQuery(document).ready(function(){

});            </script>
<style type="text/css">#megamenu_bg_12906 {background: url(http://umgroups.com/cambodia/wp-content/uploads/2015/11/mega-menus-bg-haevy02.jpg)   no-repeat;}
@media ( max-width:990px ) { #megamenu_bg_12906 {background: none;}}
.vc_custom_1429088509675{background-color: #ffffff ;}
.vc_custom_1428630807824{border-top-width: 1px !important;border-right-width: 1px !important;border-bottom-width: 1px !important;border-left-width: 1px !important;padding-top: 10px !important;padding-right: 10px !important;padding-bottom: 10px !important;padding-left: 10px !important;background-color: #474c5c !important;border-left-color: #393e4f !important;border-left-style: solid !important;border-right-color: #393e4f !important;border-right-style: solid !important;border-top-color: #393e4f !important;border-top-style: solid !important;border-bottom-color: #393e4f !important;border-bottom-style: solid !important;}
.vc_custom_1428630829435{border-top-width: 1px !important;border-bottom-width: 1px !important;padding-top: 10px !important;padding-right: 10px !important;padding-bottom: 10px !important;padding-left: 10px !important;background-color: #474c5c !important;border-top-color: #393e4f !important;border-top-style: solid !important;border-bottom-color: #393e4f !important;border-bottom-style: solid !important;}
.vc_custom_1428630845995{border-top-width: 1px !important;border-right-width: 1px !important;border-bottom-width: 1px !important;border-left-width: 1px !important;padding-top: 10px !important;padding-right: 10px !important;padding-bottom: 10px !important;padding-left: 10px !important;background-color: #474c5c !important;border-left-color: #393e4f !important;border-left-style: solid !important;border-right-color: #393e4f !important;border-right-style: solid !important;border-top-color: #393e4f !important;border-top-style: solid !important;border-bottom-color: #393e4f !important;border-bottom-style: solid !important;}
.vc_custom_1428658565232{margin-bottom: 0px ;padding-top: 80px ;padding-bottom: 20px ;background-color: #2b2e3f ;}
.vc_custom_1447923789402{margin-top: 12px !important;}
.vc_custom_1429520259737{margin-top: -11px !important;}
.vc_custom_1429079722061{margin-bottom: 20px !important;}
#section-1 h2:after,#section-1 h2:before{background-color:#db9224;}
.vc_custom_1429079752030{margin-bottom: 20px !important;}
#section-2 h2:after,#section-2 h2:before{background-color:#db9224;}
.vc_custom_1429079765991{margin-bottom: 20px !important;}
#section-3 h2:after,#section-3 h2:before{background-color:#db9224;}
.vc_custom_1428658579576{margin-top: 0px ;margin-bottom: 0px ;padding-bottom: 80px ;background-color: #2b2e3f ;}
.vc_custom_1429079778018{margin-bottom: 20px !important;}
#section-4 h2:after,#section-4 h2:before{background-color:#db9224;}
.vc_custom_1427084971825{padding-right: 40px !important;}
.vc_custom_1429079787760{margin-bottom: 20px !important;}
#section-5 h2:after,#section-5 h2:before{background-color:#db9224;}
.vc_custom_1429079800113{margin-bottom: 20px !important;}
#section-6 h2:after,#section-6 h2:before{background-color:#db9224;}
.vc_custom_1429091507102{margin-top: 0px ;margin-bottom: 0px ;padding-top: 20px ;padding-bottom: 20px ;background-color: #212330 ;}
.vc_custom_1429092087166{padding-top: 15px !important;}
.vc_custom_1429147194406{padding-right: 0px !important;padding-left: 0px !important;}</style><div class="jquery-media-detect"></div>
	<script type="text/javascript">
			jQuery(document).ready(function() {
				// CUSTOM AJAX CONTENT LOADING FUNCTION
				var ajaxRevslider = function(obj) {
				
					// obj.type : Post Type
					// obj.id : ID of Content to Load
					// obj.aspectratio : The Aspect Ratio of the Container / Media
					// obj.selector : The Container Selector where the Content of Ajax will be injected. It is done via the Essential Grid on Return of Content
					
					var content = "";

					data = {};
					
					data.action = 'revslider_ajax_call_front';
					data.client_action = 'get_slider_html';
					data.token = 'f3068ad0a0';
					data.type = obj.type;
					data.id = obj.id;
					data.aspectratio = obj.aspectratio;
					
					// SYNC AJAX REQUEST
					jQuery.ajax({
						type:"post",
						url:"http://umgroups.com/cambodia/wp-admin/admin-ajax.php",
						dataType: 'json',
						data:data,
						async:false,
						success: function(ret, textStatus, XMLHttpRequest) {
							if(ret.success == true)
								content = ret.data;								
						},
						error: function(e) {
							console.log(e);
						}
					});
					
					 // FIRST RETURN THE CONTENT WHEN IT IS LOADED !!
					 return content;						 
				};
				
				// CUSTOM AJAX FUNCTION TO REMOVE THE SLIDER
				var ajaxRemoveRevslider = function(obj) {
					return jQuery(obj.selector+" .rev_slider").revkill();
				};

				// EXTEND THE AJAX CONTENT LOADING TYPES WITH TYPE AND FUNCTION
				var extendessential = setInterval(function() {
					if (jQuery.fn.tpessential != undefined) {
						clearInterval(extendessential);
						if(typeof(jQuery.fn.tpessential.defaults) !== 'undefined') {
							jQuery.fn.tpessential.defaults.ajaxTypes.push({type:"revslider",func:ajaxRevslider,killfunc:ajaxRemoveRevslider,openAnimationSpeed:0.3});   
							// type:  Name of the Post to load via Ajax into the Essential Grid Ajax Container
							// func: the Function Name which is Called once the Item with the Post Type has been clicked
							// killfunc: function to kill in case the Ajax Window going to be removed (before Remove function !
							// openAnimationSpeed: how quick the Ajax Content window should be animated (default is 0.3)
						}
					}
				},30);
			});
			
function checkdate()
{
	var date1=document.getElementByClass("startdate");
	var date2=document.getElementByClass("enddate");
	console.log(date1);
	if(date1.value>date2.value)
	{
//printf("asdf");
		alert("Date is not valid end date must greater than start date");
		return false;
	}
	else
	{
		return true;
	}
}

function myFunction() {
							var table = document.getElementById("myTable");
							var row = table.insertRow(0);
							var cell1 = row.insertCell(0);
							var cell2 = row.insertCell(1);
							var cell3 = row.insertCell(2);
							var cell4 = row.insertCell(3);
							cell1.innerHTML = "<input type='text' name='highschool[0]' style='height:45px;'>";
							cell2.innerHTML = "<input type='date' class='startdate' name='highschool[1]' style='height:45px;'>";
							cell3.innerHTML = "<input type='date' class='enddate' name='highschool[2]' style='height:45px;'>";
							cell4.innerHTML = "<input type='text' name='highschool[3]' style='height:45px;'>";
						}
						function myDeleteFunction() {
							document.getElementById("myTable").deleteRow(0);
						}
// for education uni
function myFunction1() {
							var table = document.getElementById("myTable1");
							var row = table.insertRow(0);
							var cell1 = row.insertCell(0);
							var cell2 = row.insertCell(1);
							var cell3 = row.insertCell(2);
							var cell4 = row.insertCell(3);
							cell1.innerHTML = "<input type='text' name='uni[0]' style='height:45px;'>";
							cell2.innerHTML = "<input type='date' class='startdate'   name='uni[1]' style='height:45px;'>";
							cell3.innerHTML = "<input type='date' class='enddate' name='uni[2]' style='height:45px;'>";
							cell4.innerHTML = "<input type='text' name='uni[3]' style='height:45px;'>";
						}
						function myDeleteFunction1() {
							document.getElementById("myTable1").deleteRow(0);
						}
// for education others
function myFunction2() {
							var table = document.getElementById("myTable2");
							var row = table.insertRow(0);
							var cell1 = row.insertCell(0);
							var cell2 = row.insertCell(1);
							var cell3 = row.insertCell(2);
							var cell4 = row.insertCell(3);
							cell1.innerHTML = "<input type='text' name='other[0]' style='height:45px;'>";
							cell2.innerHTML = "<input type='date' class='startdate' name='other[1]' style='height:45px;'>";
							cell3.innerHTML = "<input type='date' class='enddate' name='other[2]' style='height:45px;'>";
							cell4.innerHTML = "<input type='text' name='other[3]' style='height:45px;'>";
						}
						function myDeleteFunction2() {
							document.getElementById("myTable2").deleteRow(0);
						}

// for foreign lanaguage
function myFunction3() {
							var table = document.getElementById("myTable3");
							var row = table.insertRow(0);
							var cell1 = row.insertCell(0);
							var cell2 = row.insertCell(1);
							var cell3 = row.insertCell(2);
							var cell4 = row.insertCell(3);
							cell1.innerHTML = "<input type='text' name='foreignlanguage[0]'>";
							cell2.innerHTML = "<select name='foreignlanguage[1]' style='height:45px;'><option>Beginner</option><option>Conversational</option><option>Business</option><option>Fluent</option></select>";
													
							cell3.innerHTML = "<select name='foreignlanguage[2]' style='height:45px;'><option>Beginner</option><option>Conversational</option><option>Business</option><option>Fluent</option></select>";
							cell4.innerHTML = "<select name='foreignlanguage[3]' style='height:45px;'><option>Beginner</option><option>Conversational</option><option>Business</option><option>Fluent</option></select>";
						}
						function myDeleteFunction3() {
							document.getElementById("myTable3").deleteRow(0);
						}
// for working experience
function myFunction4() {
							var table = document.getElementById("myTable4");
							var row = table.insertRow(0);
							var cell1 = row.insertCell(0);
							var cell2 = row.insertCell(1);
							var cell3 = row.insertCell(2);
							var cell4 = row.insertCell(3);
							var cell5 = row.insertCell(4);
							cell1.innerHTML = "<input type='text' name='workexperience[0]'>";
							cell2.innerHTML = "<input type='text' name='workexperience[1]'>";
							cell3.innerHTML = "<input type='text' name='workexperience[2]'>";
							cell4.innerHTML = "<input type='text' name='workexperience[3]'>";
							cell5.innerHTML = "<input type='text' name='workexperience[5]'>";
						}
						function myDeleteFunction4() {
							document.getElementById("myTable4").deleteRow(0);
						}
// for references

						function myFunction5() {
							var table = document.getElementById("myTable5");
							var row = table.insertRow(0);
							var cell1 = row.insertCell(0);
							var cell2 = row.insertCell(1);
							var cell3 = row.insertCell(2);
							var cell4 = row.insertCell(3);
							var cell5 = row.insertCell(4);
							
							cell1.innerHTML = "<input type='text' name='reference[0]'>";
							cell2.innerHTML = "<input type='text' name='reference[1]'>";
							cell3.innerHTML = "<input type='text' name='reference[2]'>";
							cell4.innerHTML = "<input type='text' name='reference[3]'>";
							cell5.innerHTML = "<input type='text' name='reference[4]'>";
						
						}
						function myDeleteFunction5() {
							document.getElementById("myTable5").deleteRow(0);
						}
						
					</script>

<script src="js/modernizr.js"></script>
<script>Modernizr.load({
  test: Modernizr.inputtypes.date,
  nope: ['http://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.7/jquery-ui.min.js', 'jquery-ui.css'],
  complete: function () {
    $('input[type=date]').datepicker({
      dateFormat: 'yy-mm-dd'
    }); 
  }
});
</script>
<script>
    function checkFile()
    {   
    //	alert("sdf");

    var node_list = document.getElementById('certificatecopy'); //document.getElementsByTagName('input');
   // alert(node_list.value);
   // for (var i = 0; i < node_list.length; i++) 
    //{

      //  var node = node_list[i];
   //     if (node.getAttribute('type') == 'file') 
     //   {
            var sFileName = node_list.value;
            var sFileExtension = sFileName.split('.')[sFileName.split('.').length - 1];
            var iFileSize = node_list.files[0].size;
            var iConvert=(node_list.files[0].size/10485760).toFixed(2);
            
       // }
      //  	alert(sFileName);
        
        if (sFileExtension != "zip" )//&& )//&& sFileExtension != "doc" && sFileExtension != "docx" )
        {   
            txt="File type : "+ sFileExtension+"\n\n";
           
            txt+="Please make sure your file is in pdf or doc format and less than 10 MB.\n\n";
            alert(txt);
        }
        else if(iFileSize>10485760)
        {
        	txt+="Size: " + iConvert + " MB \n\n";
        	txt+="Please make sure your file is in less than 10 MB.\n\n";
        }
    //}
}
    </script>
</body>


</html>