<?php

echo 'kwek is executed';

?>