
<?php
session_start();
if(!isset($_SESSION["Username"])){ //if login in session is not set
    header("Location: login.php");
}

include '../connect.php';

//var_dump($_POST['qid']);
$totalscore=$_POST['totalscore'];
$markername=$_POST['markername'];
$remark=$_POST["remark"];
$recommand=$_POST["recommand"];
$jno=$_POST["jobno"];

//echo $recommand;
if($recommand=="recommanded")
{
	$status="recommand";
	//echo $status;
	$stmt = $conn->prepare( "UPDATE  tblapplicationform SET gradingremark=? , status=? WHERE JobNo=?" );

    $stmt->bind_param( "sss", $remark,$status,$jno);

    $stmt->execute();
    //if($stmt)
    //{
    	// header('location:acceptedarchieve.php');	
    //}
    //else
    //{
    //	echo mysql_error();
    //}
    	 $url="acceptedarchieve.php";
		
		 echo '<script> window.location = "'.$url.'"</script>';
    
}

else if($recommand=="notrecommanded")
{
	$status1="notrecommanded";


	$stmt = $conn->prepare( "UPDATE  tblapplicationform SET gradingremark=? ,status=? WHERE JobNo=?" );

    $stmt->bind_param( "sss", $remark,$status1,$jno);

    $stmt->execute();
    //if($stmt)
    //{
    	 //header('location:rejectedarchieve.php');	
    	  $url1="rejectedarchieve.php";
		
		 echo '<script> window.location = "'.$url1.'"</script>';
    //}
    //else
    //{
    //	echo mysql_error();	
    //}
    	
}
else if($recommand=="recommandedundercandidate")
{
	$status2="recommandedundercandidate";

	$stmt = $conn->prepare( "UPDATE  tblapplicationform SET gradingremark=? ,status=? WHERE JobNo=?" );

    $stmt->bind_param( "sss", $remark,$status2,$jno);

    $stmt->execute();
    // if($stmt)
    //{
    	$url2="onprocess.php";
		
		echo '<script> window.location = "'.$url2.'"</script>';
    	//header('location:onprocess.php');	
    //}
    //else
    //{
   // 	echo mysql_error();	
    //}
}



/*
while ($x<count($_POST['qid'])) {
	$question=$_POST['qid'][$x];
	$answer=$_POST['answer'][$x];
	
	$stmt = $conn->prepare( "INSERT INTO `answer_list`(`JobNo`, `QuestionID`, `Answer`) VALUES (?,?,?)" );

	$stmt->bind_param( "sss",$jobid,$question,$answer);

	$stmt->execute();
	//$sql ="INSERT INTO `answer_list`(`JobNo`, `QuestionID`, `Answer`) VALUES ('$jobid','$question','$answer')";
	//echo $sql.'<br>';
	$x++;
	
}
if($stmt)
{
	$status="wait grading test";
	$is_active=0;

$stmt1 = $conn->prepare( "UPDATE  tblapplicationform SET status=?,Is_Active=? WHERE JobNo=?" );
$stmt1->bind_param( "sss", $status,$is_active, $jobid);
$stmt1->execute();
if($stmt1)
{
		header("location:successquestion.php");
}

}
	*/			
//update status to 'wait grading test' and isactive=0

?>