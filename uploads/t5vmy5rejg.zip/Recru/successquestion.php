<html>
<head>
<link rel="shortcut icon" href="js/small-logo1.png">

<title> Apply for Job Vacancy | UMG Myanmar</title>
<style type="text/css">
{
	body
	{
		backgroud-color:black;
	}
	
	#div
	{
		padding:20px;
		mergin:20px;
		width:800px;
		height:300px;
		border: none !important;
		backgroud-color:#0000000;
	}
}
</style>
</head>
<body backgroud-color="black">
<div id="div" style="padding:200px;mergin-right:100px;height:300px;width:500px" align="center">
<img id="logomenurevealmobile" src="js/small-logo1.png" alt="" class="img-responsive halfsize" width="150">
</br>
</br>
</br>
</br>
<table align="center">
<tr><td>
<p ><h1 style="color:blue;">Congratulations!!</h1></p>
<p> <h3>for successfully answer the questions.</h3>
<a href="windowclose.php">Close the window</a>

<a href="index.php">Go To Home >></a>
</p><td></tr>
</table>
</div>
<input type="button" class="btn btn-success"
                       style="font-weight: bold;display: inline;"
                       value="Close"
                       onclick="closeMe()">
<script type="text/javascript">
function closeMe()
{
    window.opener = self;
    window.close();
}	


</script>

</body>

</html>