<html>
<head>
<link rel="shortcut icon" href="js/small-logo1.png">

<title> Apply for Job Vacancy | UMG Myanmar</title>
<style type="text/css">
{
	body
	{
		backgroud-color:black;
	}
	
	#div
	{
		padding:20px;
		mergin:20px;
		width:800px;
		height:300px;
		border: none !important;
		backgroud-color:#0000000;
	}
}
</style>
<script>
    function closeWindow() {
        window.open('','_parent','');
        window.close();
    }
</script> 
</head>
<body backgroud-color="black">
<div id="div" style="padding:200px;mergin-right:100px;height:300px;width:500px" align="center">
<img id="logomenurevealmobile" src="js/small-logo1.png" alt="" class="img-responsive halfsize" width="150">
</br>
</br>
</br>
</br>
<table align="center">
<tr><td>
<p ><h1 style="color:red;">Warning!!</h1></p>
<p> <h3>Sorry You Are Not Allow To See This Page</h3></p>
<p> <h3><input type="button" name="close" value="Exit From Program" onclick="closeWindow()"></h3></p>
<td></tr>

</table>
</div>
</body>

</html>