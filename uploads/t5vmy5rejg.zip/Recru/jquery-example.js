$(document).ready(function(){
  $("#main").html("JQUERY Loaded from " + JQUERY_CDN);
});