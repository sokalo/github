<?php
include("connect.php");
$xb=1;
$qarray=array();
$qele=array();
$ansarray=array();
$ansele=array();
$jno=$_POST["jobno"];

foreach($_POST["qid"] as $k=>$v)
{
	$qarray[]=$k;
	$qele[]=$v;
	//$new_arr[$k]=$v->__toString();
}
foreach($_POST["answer"] as $k=>$v)
{
	$ansarray[]=$k;
	$ansele[]=$v;
	//$new_arr[$k]=$v->__toString();
}
//$a=$new_arr;
/*
for($i=0;$i<count($_POST["qid"]);$i++)
{
$ele=($_POST["qid"]);	
}*/


for($x = 1; $x <= count($_POST["qid"]); $x++)
     {    
     $str[] = "('{$qele[$x]}','{$ansele[$x]}')";  
     }  
  $s = implode(',',$str);  
//$question=implode(",",$qele);
//$ans=implode(",",$ansele);
/*
while($xb<100)
{
	$array=var_dump($_POST);	
	$xb++;
}	

///var_dump($_POST);*/
//call_user_func_array('var_dump', $array);
//echo $education;
//echo $a;
//$i=0;
 $sql ="INSERT INTO answer_list (QuestionID,Answer) VALUES $s";
 $result = $conn->query($sql);
  echo $sql;
/*

$stmt = $conn->prepare("INSERT INTO `answer_list` (JobNo,QuestionID,Answer)
                     values(?,?)");

 foreach($_POST["qid"] as $value){
  $stmt->bind_param("s",$jno, $question, $ans);
  $stmt->execute();*/
 //}



?>
